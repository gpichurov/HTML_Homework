<?php

class Employee extends Person
{

}